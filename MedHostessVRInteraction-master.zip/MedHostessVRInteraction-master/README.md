# MedHostessVRInteraction
Using Oculus Rift, an interactive experience with a motion capture animated medical hostess
